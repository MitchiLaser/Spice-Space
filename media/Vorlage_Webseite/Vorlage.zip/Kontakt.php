<?php

function clear_user_input($value) {
	if (get_magic_quotes_gpc()) $value=stripslashes($value);
	$value= str_replace( "\n", '', trim($value));
	$value= str_replace( "\r", '', $value);
	return $value;
}

$email = $_POST['email'];

### Konfiguration ###
$mailto = "somebody@example.com"; # Adresse
$mailsubj = "Kontaktanfrage von der Website"; # Betreff
### Ende Konfiguration ###

$mailhead = "From: $email\n";

$body ="Werte, die von der Website übermittelt wurden:\n";

foreach ($_POST as $key => $value) {
	$key = clear_user_input($key);
	$value = clear_user_input($value);
	if ($key=='extras') {	
	    if (is_array($_POST['extras']) ){
            $body .= "$key: ";
            $counter = 1;
            foreach ($_POST['extras'] as $value) {
                if (sizeof($_POST['extras']) == $counter) {
                    $body .= "$value\n";
                    break;
                }
                else {
                    $body .= "$value, ";
                    $counter += 1;
                }
		    }
        } 
        else {
            $body .= "$key: $value\n";
        }
	} 
	else {
		$body .= "$key: $value\n";
	}
}

mail($mailto, $mailsubj, $body, $mailhead);

?>

<!DOCTYPE html>
<html lang="de">
    <head>
        <meta charset="utf-8" />
        <title>Kontaktformular-Anfrage</title>
        <link href="style.css" type="text/css" rel="stylesheet">
    </head>
    <body>
        <div id="ButtonOutside">
            <p>Ihre Anfrage wurde gesendet<br>Sie können dieses Fenster nun schlie&szlig;en</p>
        </div>
    </body>
</html>
