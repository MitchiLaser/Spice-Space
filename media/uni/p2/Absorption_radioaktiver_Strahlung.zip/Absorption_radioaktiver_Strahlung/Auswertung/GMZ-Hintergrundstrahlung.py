#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
from scipy.stats import norm
import kafe_latte as latte
from kafe.function_library import linear_2par

## PGF Support
latte.setupPgf()

###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/GMZ-Hintergrundstrahlung.txt" # Pfad zur CSV Datei mit den Messwerten

inj_File = "./LaTeX_inject/GMZ-Hintergrundstrahlung.tex" # Ausgabedatei LaTeX-Injection
inj_Param_name = "GmzHintergrundstrahlung"

export_file = "./export/Hintergrundstrahlung.txt" # Einen Parameter aus dieser Datei später wiederverwenden

num_bins = 6 # Anzahl an Balken im Histogramm
tex_round_precision = 1000 # Ab wann sollen die in LaTeX injizierten Zahlen gerundet werden?

########################################
########## Konfiguration Ende ##########
########################################


## Messreihe einlesen
data = ppk.readtxt(Messwerte)
Zaehlrate = data[1][1] / 5  # Zählrate, division durch Messdauer in Sekunden

## Zählrate: Ausgabe aus dem Programm korrigieren
for i in range(len(Zaehlrate) - 1, 1, -1):
    if i != 0:
        Zaehlrate[i] = Zaehlrate[i] - Zaehlrate[i - 1]

## Histogramm plotten
Hist = plt.hist(Zaehlrate, bins=num_bins, label="Häufigleit Messwerte", histtype='bar', align='mid', rwidth=0.8)

mu, std = norm.fit(Zaehlrate)

#x = np.linspace(-0.25, 1.25, 500)
#p = norm.pdf(x, mu, std) * 0.56 * 75
#plt.plot(x, p, label="Gauss")


## bestehender Inhalt in Ausgabedatei für LaTeX-Injection muss gelöscht werden
latte.clearFile(inj_File)

## Endergebnisse der Analyse in LaTeX-Dokument einbinden, gerundet
latte.TeX_Const(inj_File, inj_Param_name + "Mu", np.round(mu*tex_round_precision)/tex_round_precision)
latte.TeX_Const(inj_File, inj_Param_name + "St", np.round(std*tex_round_precision)/tex_round_precision)


## Plot verschönern
plt.legend(loc="upper right")           # Position der Legende
plt.xlabel("Zählrate")                  # Label X-Achse
plt.ylabel("Häufigkeit der Zählrate")   # Label X-Achse
#plt.xlim(-0.25, 1.25)                   # Bereich auf der X-Achse
#plt.ylim(0, 2)                          # Bereich auf der Y-Achse
plt.grid(axis='y', alpha=0.5)            # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_GMZ_Hintergrundstrahlung.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()


## Parameter für den Mittelwert der Gauss-Funktion exportieren, um ihn später wieder zu verwenden:
latte.clearFile(export_file)
latte.write_in_file(export_file, np.round(mu*tex_round_precision)/tex_round_precision)