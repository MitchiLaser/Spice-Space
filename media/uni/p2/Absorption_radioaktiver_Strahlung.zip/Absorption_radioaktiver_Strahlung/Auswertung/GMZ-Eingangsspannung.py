#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
import kafe_latte as latte
from kafe.function_library import linear_2par

## PGF Support
latte.setupPgf()

###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/GMZ-Eingangsspannung.csv" # Pfad zur CSV Datei mit den Messwerten

inj_File = "./LaTeX_inject/GMZ-Eingangsspannung.tex" # Ausgabedatei LaTeX-Injection
inj_Param_name = "GmzEingangsspannung"

err_U = 0.05 # relativer Fehler auf die Messung der Spannung
err_num = 0 # relativer Fehler auf die Messung der Anzahl

plateau_reg_offset = 3 # ab welchem Index beginnt das Plateau? Wichtig für Regression!

########################################
########## Konfiguration Ende ##########
########################################


## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
U = data[0]    # Spannung in V
num = data[1]  # Zählrate


## Messwerte plotten
plt.plot(U, num, "o", label="Messwerte")


## Plateau: Regression
# Rückgabewerte ################################## X-Werte ################# Y-Werte ################### X-Fehler ####################### Y-Fehler ################# Wohin plotten? # Label zum Plotten ### Plotte die Regression # Ausgabe der Ergebnisse im Terminal
pitch, shift, err_pitch, err_shift = latte.linReg( U[plateau_reg_offset::] , num[plateau_reg_offset::] , U[plateau_reg_offset::] * err_U, num[plateau_reg_offset::] * err_num, plt , "Regression Plateau" , do_plot=True , Term_Out=False)



## bestehender Inhalt in Ausgabedatei für LaTeX-Injection muss gelöscht werden
latte.clearFile(inj_File)

## Endergebnisse der Regression in LaTeX-Dokument einbinden
latte.TeX_Reg_result(inj_File, inj_Param_name + "Steigung", pitch, err_pitch)
latte.TeX_Reg_result(inj_File, inj_Param_name + "Versatz", shift, err_shift)


## Plot verschönern
plt.legend(loc="lower right")   # Position der Legende
plt.xlabel("Spannung in V")     # Label X-Achse
plt.ylabel("Ereigniszahl")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(-5, 45)                # Bereich auf der Y-Achse
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_GMZ_Eingangsspannung.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()
