#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, PhyPraKit as ppk, math
import kafe_latte as latte

## Fit-Funktion für Regression deinieren
def fit_function(x, a, b):
    return np.exp(a * x) + b

# Korrekturfunktionen
def korr_1(Wert):
    return ( Wert / (1 - Wert * Totzeit)) - Hintergrundstrahlung

def korr_2(Wert, Abstand):
    return korr_1(Wert) * 4 * Abstand**2 / ( Radius_Messrohr**2 )

# Berechnen der Grenzenergien
def gEnerg(r, rho):
    return 1,92 * np.sqrt( r**2 * rho**2 + 0.22 * r * rho )

## PGF Support
latte.setupPgf()

###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/beta_absorption.csv" # Pfad zur CSV Datei mit den Messwerten

inj_File = "./LaTeX_inject/Absorption-beta.tex" # Ausgabedatei LaTeX-Injection
inj_Param_name = "AbsorptionBeta"

Messdauer = 200 # Messdauer in s
Radius_Messrohr = latte.TeX_Extract_Var("./../Messwerte/Vars.tex", "DurchmesserFensterGMZ") #Radius der Öffnung des Geiger-Müller-Zählrohrs

Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen
Totzeit = latte.ParamExtract("./export/Totzeit.txt") # Totzeit des Messgerätes importieren

Trennung_Regressionen = int( latte.TeX_Extract_Var("./../Messwerte/Vars.tex", "BetaAbsorptionRegressionsTrennungsMesspunkt") - 1 ) # der Index, ab dem (-1 weil index)

Dichte_Alu = 2698.9

########################################
########## Konfiguration Ende ##########
########################################


latte.clearFile(inj_File)


## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
Dicke = data[0]    # Dicke in µm
Messdauer = data[1]  # Messdauer in s
Ereignisse = data[2] # Ereignissanzahl

# Korrektur der Messwerte anwenden
Zaehlrate_Korr = np.zeros( len( Dicke ) )
for i in range(len(Zaehlrate_Korr)):
    Zaehlrate_Korr[i] = korr_2( Ereignisse[i] / Messdauer[i], 41 ) # Abstand 40mm + 1 mm Fensterdicke


## Messwerte plotten
plt.plot(Dicke, Zaehlrate_Korr, "o", label="Messwerte")

## Aufteilen der 2 Regressionen:
X_Values = [
    Dicke[:Trennung_Regressionen],
    Dicke[Trennung_Regressionen:]
]
Y_Values = [
    np.log( Zaehlrate_Korr[:Trennung_Regressionen] ),
    np.log( Zaehlrate_Korr[Trennung_Regressionen:] )
]
regs_desc = ["A", "B"] # Namen für die Regressionsparameter -> LaTeX


## irgendwo müssen die Regressinsergebnisse zwischengespeichert werden
## damit man später den SChnittpunkt ermitteln kann
m = []

for i in range(len(X_Values)):

    ## Regression mit Scipy durchführen
    pitch, shift, err_pitch, err_shift = latte.linReg(X_Values[i], Y_Values[i], np.zeros(len(X_Values[i])), np.zeros(len(Y_Values[i])), plt, "")
    
    X = np.linspace( np.amin(X_Values[i]), np.amax(X_Values[i]), 1000 )
    Y = np.exp( pitch * X + shift )

    plt.plot(X, Y, label="Regression %i"%(i+1))

    latte.TeX_Reg_result(inj_File, inj_Param_name + regs_desc[i] + "a", pitch, err_pitch)
    latte.TeX_Reg_result(inj_File, inj_Param_name + regs_desc[i] + "b", shift, err_shift)

    ## Ergebise zwischenepeichern, damit man auch den Schnittpunkt bestimmen kann
    m.append(pitch)
    m.append(shift)


## Berechnen der Schnittpunkte
Schnittpunkte = []
Schnittpunkte.append( np.round( ( m[3] - m[1] ) / ( m[0] - m[2] ) ) ) # Schnittpunkt Kurven
Schnittpunkte.append( np.round( (np.log(Hintergrundstrahlung) - m[3]) / m[2] ) ) # Schnittpunkt zweite Kurve, Hintergrundstrahlung


# eigentlich wäre die nachfolgende Zeile viel schöner,
# aber ich bin einfach nur dämlich
latte.TeX_Var(inj_File, inj_Param_name + "SchnittpunktI", latte.IntToSi(Schnittpunkte, unit="\\mu{}m")[0][1:-2:] + "}" )
latte.TeX_Var(inj_File, inj_Param_name + "SchnittpunktII", latte.IntToSi(Schnittpunkte, unit="\\mu{}m")[1][1:-2:] + "}" )


## Berechnen der Absorptionskoeffizienten:
Koeff = [m[0] * 10000, m[2] * 10000, (m[0] - m[2]) * 10000]
for i in range(len(Koeff)):
    Koeff[i] = np.abs( np.round( Koeff[i] * 10 ) / 10 ) # aus allen Werten die Beträge bilden

latte.TeX_Var(inj_File, inj_Param_name + "KoeffI", latte.NumToSi(Koeff, unit="\\frac{1}{cm}")[0][1:-2:] + "}" )
latte.TeX_Var(inj_File, inj_Param_name + "KoeffII", latte.NumToSi(Koeff, unit="\\frac{1}{cm}")[1][1:-2:] + "}" )
latte.TeX_Var(inj_File, inj_Param_name + "KoeffIII", latte.NumToSi(Koeff, unit="\\frac{1}{cm}")[2][1:-2:] + "}" )


## die berechneten Koeffizienten:
ergebn = [ Koeff[1] / Dichte_Alu * 100, Koeff[2] / Dichte_Alu * 100 ]

for i in range(len(ergebn)):
    ergebn[i] = np.abs( np.round( ergebn[i] * 100 ) / 100 ) # alle Werte richtig runden

latte.TeX_Var(inj_File, inj_Param_name + "ErgebnI", latte.NumToSi(ergebn, unit="\\frac{m^2}{Kg}")[0][1:-2:] + "}" )
latte.TeX_Var(inj_File, inj_Param_name + "ErgebnII", latte.NumToSi(ergebn, unit="\\frac{m^2}{Kg}")[1][1:-2:] + "}" )

## Grenzenergien berechnen
energ = np.round( [i * 100 for i in Schnittpunkte] ) / 100 / 1000

for i in energ:
    i = gEnerg(i, Dichte_Alu)

latte.TeX_Var(inj_File, inj_Param_name + "GrenzEnergieI", latte.NumToSi(energ * 10, unit="MeV")[0][1:-2:] + "}" )
latte.TeX_Var(inj_File, inj_Param_name + "GrenzEnergieII", latte.NumToSi(energ, unit="MeV")[1][1:-2:] + "}" )



## Plot verschönern
plt.legend(loc="upper right")   # Position der Legende
plt.xlabel("Dicke in µm")       # Label X-Achse
plt.ylabel("Zählrate")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(1e3, 1e5)                # Bereich auf der Y-Achse
plt.yscale("log")
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_Absorption_Beta.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()
