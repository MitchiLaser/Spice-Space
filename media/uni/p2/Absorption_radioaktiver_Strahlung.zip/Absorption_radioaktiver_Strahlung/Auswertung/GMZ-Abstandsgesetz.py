#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
import kafe_latte as latte
from kafe.function_library import linear_2par
from scipy import optimize

## Fit-Funktion für Regression definieren
def fit_function(x, a, b):
    return np.exp(a + b * np.log(x) )


## PGF Support
latte.setupPgf()

###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/GMZ-Abstandsgesetz.csv" # Pfad zur CSV Datei mit den Messwerten

inj_File = "./LaTeX_inject/GMZ-Abstandsgesetz.tex" # Ausgabedatei LaTeX-Injection
inj_Param_name = "GmzAbstandsgesetz"

Messdauer = latte.TeX_Extract_Var("./../Messwerte/Vars.tex", "AbstandsgesetzMessdauer") # Dauer für jede Messung

Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen

print_reg_results = False ## während der Durchführung des Versuches: 
                          ## Parameter der Regression in der Komandozeile 

########################################
########## Konfiguration Ende ##########
########################################


## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
d = data[0]    # Abstand in mm
num = data[1] - (Messdauer * Hintergrundstrahlung)  # Zählungen, ohne Hintergrundstrahlung
zr = num / Messdauer # Zählrate


## Messwerte plotten
plt.plot(d, zr, ".", label="Zählrate")


## Regresion
params, params_covariance = optimize.curve_fit(fit_function, d, zr, maxfev=20000)
params_err = np.sqrt(np.diag(params_covariance))

### Parameter aus der Regression ausgeben
if print_reg_results:
    print(params)
    print(params_err)


## Regression plotten
X = np.linspace(np.amin(d), np.amax(d), 1000)
Y = fit_function(X, params[0], params[1])
plt.plot(X, Y, label="Regression")


## bestehender Inhalt in Ausgabedatei für LaTeX-Injection muss gelöscht werden
latte.clearFile(inj_File)

param_desc = ["a","b"] # Name für Parameter 1 + 2

## Endergebnisse der Regression in LaTeX-Dokument einbinden
for i in range(len(params)):
    latte.TeX_Reg_result(inj_File, inj_Param_name + param_desc[i], params[i], params_err[i])


## Plot verschönern
plt.legend(loc="upper right")   # Position der Legende
plt.xlabel("Abstand in mm")     # Label X-Achse
plt.ylabel("Zählrate")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(-5, 45)                # Bereich auf der Y-Achse
plt.xscale("log")
plt.yscale("log")
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_GMZ_Abstandsgesetz.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()
