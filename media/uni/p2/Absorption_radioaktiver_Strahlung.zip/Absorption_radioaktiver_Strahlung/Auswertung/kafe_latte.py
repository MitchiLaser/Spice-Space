#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe
import PhyPraKit as ppk
from kafe.function_library import linear_2par
from scipy import optimize



#####################
##### PGF-Plots #####
#####################

def setupPgf():
	from matplotlib.backends.backend_pgf import FigureCanvasPgf
	matplotlib.backend_bases.register_backend('pdf', FigureCanvasPgf)

	matplotlib.rcParams.update({
		"pgf.texsystem": "pdflatex",
		'font.family': 'serif',
		'text.usetex': True,
		'pgf.rcfonts': False,
	})


def cm2inch(*val):
    inch = 2.54
    if isinstance(val[0], val):
        return val(i/inch for i in val[0])
    else:
        return val(i/inch for i in val)



##########################
##### Kafe-Interface #####
##########################

## Lineare Regression
def linReg(X_values, Y_values, X_err, Y_err, plot_obj, plot_lable, quiet_fit=True, do_plot=False, Term_Out=False):
	kdata = kafe.Dataset(data=[X_values, Y_values])
	kdata.add_error_source('x', 'simple', X_err)
	kdata.add_error_source('y', 'simple', Y_err)
	kfit = kafe.Fit(kdata, linear_2par)
	kfit.do_fit(quiet=quiet_fit)

	## Daten aus Regression extrahieren
	pitch, shift = kfit.get_parameter_values()[:2]
	err_pitch, err_shift = kfit.get_parameter_errors()[:2]
	
	
	## falls gewünscht: Ergebnisse in der Komandozeile ausgeben
	if Term_Out == True:
		print("")
		print("Ergebnis lineare Regression:")
		print("f(x) = m * x + c")
		print("")
		print("m = %f ± %f" %(pitch, err_pitch))
		print("c = %f ± %f" %(shift, err_shift))
		print("")
	
	
	
	## falls gewünscht: plotte die Funktion
	if do_plot != False and plot_obj:
		X = np.linspace(np.amin(X_values), np.amax(X_values), 1000)
		Y = X * pitch + shift
		plot_obj.plot(X, Y, label = plot_lable) # label="Regressionsgerade: f(x) = (%f ± %f) * x + (%f ± %f)"%(pitch, err_pitch, shift, err_shift)
	
	return pitch, shift, err_pitch, err_shift



##################################
##### LaTeX-Inject-Interface #####
##################################

# einfach etwas in eine Datei schreiben
def write_in_file(Filename, value):
	file = open(Filename,"a")
	file.write(str(value))
	file.close()

# Datei, in der die ganzen Sachen gespeichert werden sollen, muss vorher gelöscht werden
def clearFile(Filename):
	file = open(Filename,"r+")
	file.truncate(0)
	file.close()

# speichere eine Variable in einer TeX datei
def TeX_Var(Filename, var_name, var_value):
	file = open(Filename,"a")
	file.write("\\newcommand{\%s}{%s}\n"%(var_name, var_value))
	file.close()

# speichere eine Konstante in einer TeX datei
def TeX_Const(Filename, var_name, var_value):
	file = open(Filename,"a")
	file.write("\\newcommand{\%s}{%s}\n"%(var_name, str(var_value).replace('.',',')))
	file.close()

# speichere einen Regressionsparameter mit Fehler in einer TeX datei
def TeX_Reg_result(Filename, var_name, reg_param, reg_param_err):
	file = open(Filename,"a")

	multiplyer = 1

	while reg_param_err < 10:
		multiplyer *= 10
		reg_param *= 10
		reg_param_err *= 10

	reg_param = round(reg_param) / multiplyer
	reg_param_err = int(round(reg_param_err))

	# speicher den Wert des Parameters mit Fehler, sodass dieser als Wert in einer Siunit-Umgebung verwendet werden kann
	file.write("\\newcommand{\%s}{%s(%s)}\n"%(var_name, str(reg_param).replace('.',','), str(reg_param_err).replace('.',',')))
	
	# speichere den parameter ohne Fehler
	file.write("\\newcommand{\%s}{%s}\n"%(var_name + "Val", str(reg_param).replace('.',',')))

	# speicher den Fehler des Parameters
	file.write("\\newcommand{\%s}{%s}\n"%(var_name + "Err", str(reg_param_err / multiplyer).replace('.',',')))

	file.close()

# speichere Tabelleninhalt in TeX-Datei
def Tex_Tab_Content(Filename, tab_name, tab_content):
	file = open(Filename,"a")

	file.write("\\newcommand{\%s}{\n%s\n}\n"%(tab_name, tab_content))
	
	file.close()


def NumToSi(num, unit=""):
	newNum = []

	for i in range(len(num)):
		if unit != "":
			newNum.append("$\\SI{" + str(num[i]).replace('.',',') + "}{" + unit + "}$")
		else:
			newNum.append("$\\SI{" + str(num[i]).replace('.',',') + "}{}$")
		
	return newNum


def IntToSi(num, unit=""):
	newNum = []

	for i in num:
		i = int(i)

	for i in range(len(num)):
		newNum.append("$\\SI{" + str(num[i])[:-2:] + "}{" + unit + "}$")
		
	return newNum



###########################
##### Table-Generator #####
###########################

# create table from two-dimensional array
def Tab_From_Array(data):

	num_cols = len(data)
	num_rows = len(data[0])

	Table = ""

	for i in range(num_rows):
		for j in range(num_cols):
			Table = Table + str(data[j][i])
			if j != (num_cols - 1):
				Table = Table + " & "
		
		Table += " \\\\"
		if i != (num_rows - 1):
			Table += "\n"

	return Table

# cerate table-content from CSV entries
def Tab_Content_From_CSV(Filename):
	description, data = ppk.readCSV(Filename)

	return Tab_From_Array(data)


# cerate table-content from CSV entries which are numbers and might have units
def Tab_Content_From_CSV_Nums(Filename, units_math=""):
	description, data = ppk.readCSV(Filename)

	num_cols = len(data)     # löschen ?
	num_rows = len(data[0])  # löschen ?

	newData = []

	for i in range(len(data)):
		newData.append([])
		for j in range(len(data[0])):
			if units_math != "":
				newData[i].append("$\\SI{" + str(data[i][j]).replace('.',',') + "}{" + units_math[i] + "}$")
			else:
				newData[i].append("$\\SI{" + str(data[i][j]).replace('.',',') + "}{}$")
		
	return Tab_From_Array(newData)



###################################
##### LaTeX-Extract-Interface #####
###################################

# extract a variable from a LaTeX file
def TeX_Extract_Var(Filename, var_name):
	file = open(Filename, "r")

	if file.mode == 'r':
		content = file.readlines()

	for i in content:
		if i.find(var_name) != -1:
			Line = i

	file.close()

	return float( Line.split('{')[-1].split('}')[0].replace(',','.') )

# extract a parameter from a txt file that a script is using which is a result from another script
def ParamExtract(Filename):
	file = open(Filename, "r")

	if file.mode == 'r':
		content = file.readlines()
	
	param = content[0]

	file.close()
	
	return float(param)


#############################
##### Farben generieren #####
#############################

def gradient(num):
    HalfCurveLength = int(np.round(num / 2))
    HalfCurveLength += (HalfCurveLength % 2)

    CurveColors = np.round(np.linspace(0, 255, HalfCurveLength, endpoint=True)).astype(int)
    CurveColorsReversed = np.asarray(CurveColors[::-1])

    R = np.append(CurveColorsReversed, np.zeros(num - HalfCurveLength))
    G = np.append(CurveColors, CurveColorsReversed)
    B = np.append(np.zeros(num - HalfCurveLength), CurveColors)

    Hex = []
    for i in range(num):
        Hex.append( rgb2hex(R[i], G[i], B[i]) )
    return Hex

def rgb2hex(r, g, b):
    return "#{:02x}{:02x}{:02x}".format(r,g,b)
