#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, PhyPraKit as ppk, math
import kafe_latte as latte

# Korrekturfunktionen
def korr_1(Wert):
    return ( Wert / (1 - Wert * Totzeit)) - Hintergrundstrahlung


Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen
Totzeit = latte.ParamExtract("./export/Totzeit.txt") # Totzeit des Messgerätes importieren


## PGF Support
latte.setupPgf()

Dichten = [2.14,8.40,0.68,1.18,1.378,2.71,7.80,1.25]
Zählrate = np.array([84, 45, 80, 84, 93, 66, 52, 82]) / 30


Zählrate_korr = []

for i in Zählrate:
    Zählrate_korr.append( np.round( korr_1(i) * 100 ) / 100 )

#print(Zählrate_korr)



plt.plot(Dichten, Zählrate_korr, ".", label="Messwerte")


## Regression mit Scipy durchführen
pitch, shift, err_pitch, err_shift = latte.linReg(Dichten, Zählrate_korr, np.zeros(len(Dichten)), np.zeros(len(Zählrate_korr)), plt, "")

X = np.linspace( np.amin(Dichten), np.amax(Dichten), 1000 )
Y = pitch * X + shift

print("")
print("Ergebnis lineare Regression:")
print("f(x) = m * x + c")
print("")
print("m = %f ± %f" %(pitch, err_pitch))
print("c = %f ± %f" %(shift, err_shift))
print("")

plt.plot(X, Y, label="Regression")


## Plot verschönern
plt.legend(loc="upper right")   # Position der Legende
plt.xlabel("Dichte in $\\frac{g}{cm^3}$")       # Label X-Achse
plt.ylabel("Zählrate")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(1e3, 1e5)                # Bereich auf der Y-Achse
#plt.yscale("log")
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_Absorption_Gamma_2.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()


