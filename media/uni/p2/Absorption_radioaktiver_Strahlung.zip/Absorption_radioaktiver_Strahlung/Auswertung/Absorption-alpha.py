#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
import kafe_latte as latte
from kafe.function_library import linear_2par

def korr_1(Wert):
    return ( Wert / (1 - Wert * Totzeit)) - Hintergrundstrahlung

def korr_2(Wert, Abstand):
    return korr_1(Wert) * 4 * Abstand**2 / ( Radius_Messrohr**2 )

## PGF Support
latte.setupPgf()

###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/alpha_absorption.csv" # Pfad zur CSV Datei mit den Messwerten

#inj_File = "./LaTeX_inject/GMZ-Eingangsspannung.tex" # Ausgabedatei LaTeX-Injection
#inj_Param_name = "GmzEingangsspannung"

Messdauer = 200 # Messdauer in s
Radius_Messrohr = 4.5 #Radius der Öffnung des Geiger-Müller-Zählrohrs

Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen
Totzeit = latte.ParamExtract("./export/Totzeit.txt") # Totzeit des Messgerätes importieren

########################################
########## Konfiguration Ende ##########
########################################


## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
d = data[0] + 1   # Abstand in mm, Korrektur Fensterdicke
num = data[1] / Messdauer  # Zählrate

# Korrektur der Messwerte anwenden
num_korr = np.zeros(len(num))
for i in range(len(num)):
    num_korr[i] = korr_2(num[i], d[i])


## Messwerte plotten
plt.plot(d, num_korr, "o", label="Messwerte")


## Plot verschönern
plt.legend(loc="upper right")   # Position der Legende
plt.xlabel("Abstand in mm")     # Label X-Achse
plt.ylabel("Zählrate")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(-5, 45)                # Bereich auf der Y-Achse
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_Absorption_Alpha.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()
