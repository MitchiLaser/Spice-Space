#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
from scipy.stats import norm
import kafe_latte as latte
from kafe.function_library import linear_2par


def Totzeit(T, M_1, M_2, M_a):
    return (T / M_a) * ( 1 - np.sqrt( 1 - (M_1 + M_2 - M_a) * (M_a / (M_1 * M_2)) ) )


###################################
########## Konfiguration ##########
###################################

Messwerte = "./../Messwerte/GMZ-Totzeit.csv" # Pfad zur CSV Datei mit den Messwerten

inj_File = "./LaTeX_inject/GMZ-Totzeitermittlung.tex" # Ausgabedatei LaTeX-Injection
inj_Param_name = "GmzTotzeit"

Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen

export_file = "./export/Totzeit.txt" # Einen Parameter aus dieser Datei später wiederverwenden

########################################
########## Konfiguration Ende ##########
########################################


## Messreihe einlesen
data = ppk.readtxt(Messwerte)

Messdauer = int(data[0][0]) ## Messdauer in Sekunden
M_1 = float(data[1][0]) - (Hintergrundstrahlung * Messdauer) ## Zählrate Präparat 1
M_2 = float(data[1][1]) - (Hintergrundstrahlung * Messdauer) ## Zählrate Präparat 2
M_a = float(data[1][2]) - (Hintergrundstrahlung * Messdauer) ## Zählrate Präparat 1 + 2

tot_zeit = float(Totzeit(Messdauer, M_1, M_2, M_a))

## Parameter für die Totzeit exportieren, um ihn später wieder zu verwenden:
latte.clearFile(export_file)
latte.write_in_file(export_file, tot_zeit)

# Wert für LaTeX-Export vorbereiten
num_potenzen = 0
while(tot_zeit < 1):
    tot_zeit *= 10
    num_potenzen += 1

tot_zeit = np.round( 1000 * tot_zeit) / 1000

tex_totzeit = str(tot_zeit) + "e-" + str(num_potenzen)


## bestehender Inhalt in Ausgabedatei für LaTeX-Injection muss gelöscht werden
latte.clearFile(inj_File)

## Endergebnisse in LaTeX-Dokument einbinden, gerundet
latte.TeX_Const(inj_File, inj_Param_name + "Zeit", Messdauer)
latte.TeX_Const(inj_File, inj_Param_name + "Wert", tex_totzeit)

