#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib, matplotlib.pyplot as plt, PhyPraKit as ppk, math
import kafe_latte as latte

# Korrekturfunktionen
def korr_1(Wert):
    return ( Wert / (1 - Wert * Totzeit)) - Hintergrundstrahlung


Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen
Totzeit = latte.ParamExtract("./export/Totzeit.txt") # Totzeit des Messgerätes importieren


## PGF Support
latte.setupPgf()

Dicken = [1,2,5,10,15,22,25]
Co_60 = [11.62,10.69,9.37,7.69,5.89,4.81,3.55]
Co_137 = [14.04,10.03,7.33,5.05,2.94,2.03,1.13]

Co_60_korr = []

for i in Co_60:
    Co_60_korr.append( np.round( korr_1(i) * 100 ) / 100 )

Co_137_korr = []

for i in Co_137:
    Co_137_korr.append( np.round( korr_1(i) * 100 ) / 100 )


plt.plot(Dicken, Co_60_korr, ".", label="C0-60 Messwerte")
plt.plot(Dicken, Co_137_korr, ".", label="Cs-137 Messwerte")


## Regression mit Scipy durchführen
pitch, shift, err_pitch, err_shift = latte.linReg(Dicken, np.log(Co_60_korr), np.zeros(len(Dicken)), np.zeros(len(Co_60_korr)), plt, "")

X = np.linspace( np.amin(Dicken), np.amax(Dicken), 1000 )
Y = np.exp( pitch * X + shift )

print("")
print("Ergebnis lineare Regression:")
print("f(x) = m * x + c")
print("")
print("m = %f ± %f" %(pitch, err_pitch))
print("c = %f ± %f" %(shift, err_shift))
print("")

plt.plot(X, Y, label="Regression Co-60")


## Regression mit Scipy durchführen
pitch, shift, err_pitch, err_shift = latte.linReg(Dicken, np.log(Co_137_korr), np.zeros(len(Dicken)), np.zeros(len(Co_137_korr)), plt, "")

X = np.linspace( np.amin(Dicken), np.amax(Dicken), 1000 )
Y = np.exp( pitch * X + shift )

print("")
print("Ergebnis lineare Regression:")
print("f(x) = m * x + c")
print("")
print("m = %f ± %f" %(pitch, err_pitch))
print("c = %f ± %f" %(shift, err_shift))
print("")

plt.plot(X, Y, label="Regression Cs-137")


## Plot verschönern
plt.legend(loc="upper right")   # Position der Legende
plt.xlabel("Absorberdicke in mm")       # Label X-Achse
plt.ylabel("Zählrate")          # Label X-Achse
#plt.xlim(0, 600)                # Bereich auf der X-Achse
#plt.ylim(1e3, 1e5)                # Bereich auf der Y-Achse
plt.yscale("log")
plt.grid()                      # stelle ein Gitter dar


# Plot in Datei speichern
plt.savefig("../Medien/Plot_Absorption_Gamma_1.pgf", format='pgf', bbox_inches='tight')

# Plot anzeigen; auskommentieren, wenn Plot in Datei gespeichert werden soll
#plt.show()