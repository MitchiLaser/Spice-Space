#!/usr/bin/python
# -*- encoding: utf-8 -*-

import numpy as np, matplotlib.pyplot as plt, kafe, PhyPraKit as ppk, math
import kafe_latte as latte


# Funktionen, die später verwendet werden, um
# die Korrekturfaktoren für Tabelle 4 einzurichten
def korr_1(Wert):
    return ( Wert / (1 - Wert * Totzeit)) - Hintergrundstrahlung

def korr_2(Wert, Abstand):
    return korr_1(Wert) * 4 * Abstand**2 / ( Radius_Messrohr**2 )



## wichtige Werte importieren
Hintergrundstrahlung = latte.ParamExtract("./export/Hintergrundstrahlung.txt") # Hintergrundstrahlung einlesen
Totzeit = latte.ParamExtract("./export/Totzeit.txt") # Totzeit des Messgerätes importieren

   

latte.clearFile("./LaTeX_inject/Tables.tex")



# Tabelle 1: 'GMZ-Eingangsspannung.csv'
# LaTeX-Tabelleninhalt: '\TabGmzEingangsspannungContent'
# 1. Spalte: Spannung U in V (Einheit nicht mit angegeben)
# 2. Spalte: Zählrate, keine Einheit
latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabGmzEingangsspannungContent", latte.Tab_Content_From_CSV_Nums("./../Messwerte/GMZ-Eingangsspannung.csv", units_math=["",""]))





# Tabelle 2: 'GMZ-Totzeit.csv'
# LaTeX-Tabelleninhalt: '\TabGmzTotzeit'
# 1. Spalte: definierte Einträge
# 2. Spalte: Zählrate, keine Einheit

## Messreihe einlesen
data = ppk.readtxt("./../Messwerte/GMZ-Totzeit.csv")

Messdauer = float(data[0][0])

Messwerte = [
    data[1][0], ## Zählrate Präparat 1
    data[1][1], ## Zählrate Präparat 2
    data[1][2]  ## Zählrate Präparat 1+2
]
## Messwerte nachbearbeiten, sodass diese innerhalb einer SI-Unit Umgebung stehen:
newMesswerte = []
for i in Messwerte:
    newMesswerte.append("$\\SI{" + str(  int( np.round (float(i) - (Hintergrundstrahlung * Messdauer) ) ) ).replace('.',',') + "}{}$")

Konfiguration = [
    "Präparat 1",
    "Präparat 2",
    "Präparat 1 + 2"
]

latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabGmzTotzeit", latte.Tab_From_Array([Konfiguration, newMesswerte]))




# Tabelle 3: 'GMZ-Abstandsgesetz.csv'
# LaTeX-Tabelleninhalt: '\TabGmzAbstandsgesetz'
# 1. Spalte: Abstand in mm
# 2. Spalte: Zählrate, keine Einheit
# 3. Spalte (automatisch generiert): Zählrate in s^-1
Messdauer = latte.TeX_Extract_Var("./../Messwerte/Vars.tex", "AbstandsgesetzMessdauer") # Dauer für jede Messung

## Messreihe einlesen
data = ppk.readCSV("./../Messwerte/GMZ-Abstandsgesetz.csv")

latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabGmzAbstandsgesetz", latte.Tab_From_Array([
    data[1][0].astype(int),
    latte.NumToSi( np.round( data[1][1] - (Hintergrundstrahlung * Messdauer) ).astype(int) ),
    latte.NumToSi( np.round( (data[1][1] - - (Hintergrundstrahlung * Messdauer)) / Messdauer).astype(int) )
]))




# Tabelle 4: 'alpha_absorption.csv'
# LaTeX-Tabelleninhalt: '\TabAbsorptionAlpha'
# 1. Spalte: Abstand in mm
# 2. Spalte: Zählungen, keine Einheit
# 3. Spalte (automatisch generiert): Zählrate
# 4. Spalte (automatisch generiert): korrigierte Zählrate

Messwerte = "./../Messwerte/alpha_absorption.csv" # Pfad zur CSV Datei mit den Messwerten

Messdauer = 200 # Messdauer in s
Radius_Messrohr = latte.TeX_Extract_Var("./../Messwerte/Vars.tex", "DurchmesserFensterGMZ") #Radius der Öffnung des Geiger-Müller-Zählrohrs in mm

## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
d = data[0] + 1    # Abstand in mm, Fensterdicke korrektur
nums_in = data[1]  # Zählrate

## Zählrate bestimmem
num = np.zeros(len(nums_in))
for i in range(len(nums_in)):
    num[i] = nums_in[i] / Messdauer

## Zählrate korrigieren
num_korr = np.zeros(len(nums_in))
for i in range(len(num)):
    num_korr[i] = korr_2(num[i], d[i])


## alle Abstände in int umwandeln
for i in d:
    i = int(i)


# alle messungen in int konvertieren
for i in nums_in:
    i = int(i)

latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabAbsorptionAlpha", latte.Tab_From_Array([
    latte.IntToSi( d ),
    latte.IntToSi( nums_in ),
    latte.NumToSi( np.round(num * 1000) / 1000 ),
    latte.NumToSi( np.round(num_korr * 1000) / 1000 )
]))




# Tabelle 5: 'beta_absorption.csv'
# LaTeX-Tabelleninhalt: '\TabAbsorptionAlpha'
# 1. Spalte: Dicke in µm
# 2. Spalte: Messdauer in s
# 3. Spalte: Ereignisanzahl, keine Einheit
# 4. Spalte: (automatisch generiert) Zählrate

Messwerte = "./../Messwerte/beta_absorption.csv" # Pfad zur CSV Datei mit den Messwerten

## Messreihe einlesen
description, data = ppk.readCSV(Messwerte)
Dicke = data[0]    # Dicke in µm
Messdauer = data[1]  # Messdauer in s
Ereignisse = data[2] # Ereignissanzahl

## Zählrate bestimmem
Zaehlrate = np.zeros(len(Ereignisse))
for i in range(len(Zaehlrate)):
    Zaehlrate[i] = Ereignisse[i] / Messdauer[i]


latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabAbsorptionBeta", latte.Tab_From_Array([
    latte.IntToSi( Dicke ),
    latte.NumToSi( np.round(Messdauer * 10) / 10 ),
    latte.IntToSi( Ereignisse ),
    latte.NumToSi( np.round( Zaehlrate * 100 ) / 100 )
]))

# Tabelle 6: 'beta_absorption.csv', ist eine Weiterverarbeitung von Tabelle 5 
# LaTeX-Tabelleninhalt: '\TabAbsorptionBetaAnpassung'
# 1. Spalte: (automatisch generiert) korrigierteDicke in µm
# 2. Spalte: Messdauer in s
# 3. Spalte: Ereignisanzahl, keine Einheit
# 4. Spalte: (automatisch generiert) Zählrate
# 5. Spalte: (automatisch generiert) korrigierte Zählrate

Dicke = Dicke + 12 # Korrektur der Dicke

Zaehlrate_Korr = np.zeros( len( Zaehlrate ) )

for i in range( len( Zaehlrate ) ): # Zählrate korrigieren
    Zaehlrate_Korr[i] = korr_2(Zaehlrate[i], 41) # Der Abstand ist Konstant und die Korrektur der Glasdicke ist auch mit  drinnen


latte.Tex_Tab_Content("./LaTeX_inject/Tables.tex", "TabAbsorptionBetaAnpassung", latte.Tab_From_Array([
    latte.IntToSi( Dicke ),
    latte.NumToSi( np.round(Messdauer * 10) / 10 ),
    latte.IntToSi( Ereignisse ),
    latte.NumToSi( np.round( Zaehlrate * 100 ) / 100 ),
    latte.NumToSi( np.round( Zaehlrate_Korr * 100) / 100 )
]))