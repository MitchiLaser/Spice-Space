# Zusatzinfos, während dem Versuch gesammelt

## Versuch 1

### Versuch 1.1

verwendetes Präparat: 1375 SR-90/Y-90 Oktober 1963

### Versuch 2.1

verwendetes Präparat: 57218 Am-241, 18.11.1983

### Versuch 4.1



### Versuch 4.2

| Absorberdicke in mm | Zeit in s | Ereignisanzahl |
|:---:|:---:|:---:|
| 1  | 200 | 2308 |
| 2  | 200 | 2005 |
| 5  | 200 | 1466 |
| 10 | 200 | 1010 |
| 15 | 200 | 588 |
| 22 | 200 | 405 |
| 25 | 200 | 225 |

### Versuch 4.3

| Material | Dichte | Ereignisanzahl |
|:---:|:---:|:---:|
