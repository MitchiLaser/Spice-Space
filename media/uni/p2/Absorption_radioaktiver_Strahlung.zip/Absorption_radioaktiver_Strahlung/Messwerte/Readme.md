# Messwerte, die während dem Versuch aufgenommen werden:

## 'Vars.tex'

Beinhaltet variablen, die wärend dem Versuch gesetzt wurden

* PraeparatVersuchI: verwendete Strahlungsquelle für Versuch 1.1: 'Eingangsspannung und Plateauanstieg'
* GmzEingangsspannung: Die Eingangsspannung, mit der das GMZ nach Ablauf von Versuch 1.1 betrieben wird
* PraeparatVersuchII: verwendete Strahlungsquelle für Versuch 1.4: 'Überprüfen des Abstandsgesetzes'
* AbstandsgesetzMessdauer: Messdauer für eine Messung bei Versuch 1.4: 'Überprüfen des Abstandsgesetzes'
* PraeparatVersuchIII : verwendete Strahlenquelle für Versuch 2.1: 'Alpha-Absorption'
* MessdauerAlphaAbsorption: Messdauer für Versuch 2.1: 'Alpha-Absorption'
* DurchmesserFensterGMZ: Durchmesser des fensters im GMZ, für Versuch Versuch 2.1: 'Alpha-Absorption'
* PraeparatVersuchIIII: verwendete Strahlenquelle für Versuch 2.2: 'Beta-Absorption'
* PraeparatVersuchX: verwendete Strahlenquelle für Versuch 3.1: 'Gamma-Absorption bei Blei'

## 'GMZ-Eingangsspannung.csv'

Beinhaltet die Messwerte aus Versuch 1.1: 'Eingangsspannung und Plateauanstieg'. Die Messwerte aus CASSYLAB müssen in eine CSV-Datei umgewandelt werden

## 'GMZ-Hintergrundstrahlung.txt'

Beinhaltet die Messwerte aus Versuch 1.2; in der Datei müssen die Zeilen mit den Metadaten entfernt werden

## 'GMZ-Totzeit.csv'

Beinhaltet die Messwerte für den Versuch zur Totzeit. Die Tabelle besteht aus einer Zeile und 4 Spalten:

|Dauer jede Messung in Sekunden |  
|Messrate mit Präparat 1        |
|Messrate mit Präparat 2        |
|Messrate mit Präparat 1 + 2    |

## 'GMZ-Abstandsgesetz.csv'

Beinhaltet die Messwerte aus Versch 1.4: Abstandsgesetz nachweisen

**Ganz wichtig**: In dem Python-skript (ganz oben) und im LaTeX-Dokument (Zeile 154) die Fit-Funktion anpassen, sodass b ungefähr -2 ergibt. Außerdem darauf achten, dass die Regressionsparameter in der LaTeX-Datei richtig eingetragen werden.


## 'alpha_absorption.csv'

Messwerte aus Versuch 2.1: 'Alpha-Absorption'

| Abstand in mm | Zählrate |

## 'beta_absorption.csv'

Messwerte aus Versuch 2.2: 'Beta-Absorption'

| Dicke in µm | Zeit in s | Zählrate |