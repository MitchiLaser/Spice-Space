#!/bin/bash

## Zuerst Python-Skripte ausführen
## Gehe dazu in den Ordner mit den Skripten
cd Auswertung


## Python-Skript: 'GMZ-Eingangsspannung.py'
## erstellt den Plot 'Plot_GMZ_Eingangsspannung.pgf'
## führt eine Regression durch und 
## injiziert die daraus resultierenden Parameter über die Datei
## 'GMZ-Eingangsspannung.tex'
python3 ./GMZ-Eingangsspannung.py


## Python-Skript: 'GMZ-Hintergrundstrahlung.py'
## erstelle den Plot 'Plot-GMZ-Hintergrund-Hist.pgf'
## erstelle ein Histogramm aus den normierten Messwerten
## und lege einen Gauss drüber
## injiziert die Parameter der Gauss-Funktion über die Datei
## 'GMZ-Hintergrundstrahlung.tex'
python3 GMZ-Hintergrundstrahlung.py


## Python-Skript: 'GMZ-Totzeitermittlung.py'
## ermittle die Totzeit des GMZs
## injiziert die Dauer der Messung und die Totzeit in die LaTeX-Datei
## 'GMZ-Totzeitermittlung.tex'
python3 GMZ-Totzeitermittlung.py


## Python-Skript: 'GMZ-Abstandsgesetz.py'
## injiziert die Dauer der Messung und die Regressionsparameter in die LaTeX-Datei
## 'GMZ-Abstandsgesetz.tex'
python3 GMZ-Abstandsgesetz.py


## Python-Skript: 'Absorption-alpha.py'
## plottet die Messwerte zum Vesuch zur Alpha-Absorption
python3 Absorption-alpha.py


## Python-Skript: 'Absorption-beta.py'
## plottet die Messwerte zum Vesuch zur Beta-Absorption
## 'Absorption-beta.tex'
python3 Absorption-beta.py





###### Hier weitere Python-Skripte ausführen





## Tabelleninhalte Generieren
## Skript: 'Generate_Tables.sh'
## Ausgabedatei: 'Tables.tex'
python3 ./Generate_Tables.py



## Verzeichnis für die Skripte wieder verlassen
cd ..


## LaTeX-Datei erstellen
cd Protokoll

## Deckblatt erstellen
pdflatex --interaction=batchmode -halt-on-error deckblatt.tex
pdflatex --interaction=batchmode -halt-on-error deckblatt.tex

## main.tex erstellen
pdflatex --interaction=batchmode -halt-on-error main.tex
bibtex main.aux
pdflatex --interaction=batchmode -halt-on-error main.tex
pdflatex --interaction=batchmode -halt-on-error main.tex

## aufräumen
rm *.aux
rm *.log
rm *.out
rm *.bbl
rm *.blg
rm *.toc
rm *.lof
rm *.lot
rm *.fls
rm *.fdb_latexmk 

## Protokoll-Ordner verlassen
cd ..
